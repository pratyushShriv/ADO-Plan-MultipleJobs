from shutil import ExecError
import requests
from time import sleep
import json
from pprint import pprint as pp
from urllib3 import Retry

class VirtuosoApi(object):
    def __init__(self) -> None:
        self.api_token = ""
        self.api_url = "https://api-app2.virtuoso.qa/api"
        self.ui_url = "https://app2.virtuoso.qa"
        self.headers = {}
        self.goal = self.Goal(self)
        self.journey = self.Journey(self)
        self.plan = self.Plan(self)
        self.project_id = 0
        self._request_delay = 5

    def _set_auth_header(self) -> None:
        self.headers = {"Authorization": "Bearer " + self.api_token}
    
    def set_virtuoso_environment(self, environment) -> None:
        self.set_api_url("https://api-app2.virtuoso.qa/api")
        self.set_ui_url("https://app2.virtuoso.qa")

    def set_project_id(self, project_id: int) -> None:
        self.project_id = project_id

    def set_api_url(self, api_url: str) -> None:
        self.api_url = api_url

    def set_ui_url(self, ui_url: str) -> None:
        self.ui_url = ui_url

    def set_api_token(self, api_token: str) -> None:
        self.api_token = api_token
        self._set_auth_header()

    def make_post_request(self, url: str, payload: object, retries: int = 0) -> json:
        full_url = self.api_url + url
        response = requests.post(full_url, headers=self.headers, json=payload)
        if response.status_code != 200:
            retries += 1 
            if retries > 3:
                raise Exception("Failed api requests with status: {} - {}".format(response.status_code, response.__dict__))
            sleep(5)
            return self.make_post_request(url, payload, retries)  # Note: Return the result of the recursive call
                
        try:
            return response.json()
        except:
            raise Exception("Api response is not parsable {}".format(response.__dict__))

    def make_get_request(self, url: str, retries: int = 0) -> json:
        full_url = self.api_url + url
        response = requests.get(full_url, headers=self.headers)
        if response.status_code != 200:
            retries += 1 
            if retries > 3:
                raise Exception("Failed api requests with status: {} - {}".format(response.status_code, response.__dict__))
            sleep(5)
            return self.make_get_request(url, retries)  # Note: Return the result of the recursive call
            
        try:
            return response.json()
        except:
            raise Exception("Api response is not parsable {}".format(response.__dict__))

    def check_execution_outcome(self, execution_ids: list) -> dict:
        finished_status = ["FINISHED", "CANCELED", "FAILED"]
        outcomes = {}
        
        for exec_id in execution_ids:
            url = f"/executions/{exec_id}/status"
            execution = self.make_get_request(url)
            
            while not execution["item"]["status"] in finished_status:
                execution = self.make_get_request(url)
                sleep(self._request_delay)
            
            outcomes[exec_id] = execution["item"]["status"]
        
        return outcomes

    class Goal(object):
        def __init__(self, virtuoso_api: str) -> None:
            self.api = virtuoso_api

        def get_latest_goal_snapshots(self, goal_id: int) -> int:
            goal_snapshots = self.api.make_get_request("/goals/{}/snapshots?envelope=false".format(goal_id))
            if len(goal_snapshots) < 1:
                raise Exception("Goal {} does not have any executed journeys".format(goal_id))
            return goal_snapshots[0]

        def get_goal_snapshot(self, goal_id, snapshot_id):
            snapshot = self.api.make_get_request(
                "/snapshots/{}/goals/{}/testsuites?envelope=false".format(snapshot_id, goal_id))
            if not snapshot:
                raise Exception("Could not get snapshot {} for goal {}".format(snapshot_id, goal_id))
            return snapshot

        def get_project_goals(self, project_id):
            project_goals = self.api.make_get_request(
                "/goals/?projectId={}&archived=false&envelope=false".format(project_id))
            return project_goals

        def execute_goal(self, goal_id):
            url = "/goals/{}/execute?envelope=false".format(goal_id)
            payload = {}
            execution = self.api.make_post_request(url, payload)
            return execution["id"]

    class Journey(object):
        def __init__(self, virtuoso_api) -> None:
            self.api = virtuoso_api

        def _get_journeys_to_execute(self, journey_names: list = None, goal_ids: list = None) -> object:
            journeys_to_execute = []
            if not goal_ids:
                goal_ids = self.api.goal.get_project_goals(self.api.project_id).keys()
            for goal_id in goal_ids:
                snapshot_id = self.api.goal.get_latest_goal_snapshots(goal_id)
                snapshot = self.api.goal.get_goal_snapshot(goal_id, snapshot_id)
                for journey in snapshot.values():
                    journey_id = journey["id"]
                    journey_title = journey["title"]
                    journey_data = {
                        "id": journey_id,
                        "title": journey_title,
                        "goalId": goal_id,
                        "projectId": self.api.project_id,
                        "snapshotId": snapshot_id
                    }
                    if journey_names:
                        if journey_title in journey_names:
                            journeys_to_execute.append(journey_data)
                    else:
                        journeys_to_execute.append(journey_data)
            return journeys_to_execute

        def execute_journeys(self, journey_names: list = None, goal_ids: list = None):
            journeys_to_execute = self._get_journeys_to_execute(journey_names, goal_ids)
            execution_ids = []
            for journey_to_execute in journeys_to_execute:
                payload = {
                    "tags": ["Automated"],
                    "suiteIds": [journey_to_execute["id"]]
                }
                url = "/goals/{}/snapshots/{}/execute?envelope=false".format(journey_to_execute["goalId"],
                                                                             journey_to_execute["snapshotId"])
                execution = self.api.make_post_request(url, payload)
                execution_id = execution.get("id")
                if not execution_id:
                    raise Exception("Execution with id {} not found".format(execution_id))
                execution_ids.append(execution_id)
            return execution_ids
    
    class Plan(object):
        def __init__(self, virtuoso_api) -> None:
            self.api = virtuoso_api

        def execute_plan(self, plan_id):
            url = "/plans/executions/{}/execute".format(plan_id)
            payload = {}
            execution = self.api.make_post_request(url, payload)
            return [job["id"] for job in execution["item"]["jobs"].values()]
